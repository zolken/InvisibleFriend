-- phpMyAdmin SQL Dump
-- version 4.3.8
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 27, 2015 at 05:33 AM
-- Server version: 5.5.40-36.1
-- PHP Version: 5.4.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `zolken_invisiblefriend`
--
CREATE DATABASE IF NOT EXISTS `zolken_invisiblefriend` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `zolken_invisiblefriend`;

DELIMITER $$
--
-- Procedures
--
DROP PROCEDURE IF EXISTS `delete_user`$$
CREATE DEFINER=`zolken`@`localhost` PROCEDURE `delete_user`(IN `did` INT UNSIGNED)
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
    COMMENT 'Delete an user'
begin
delete from users where id=did;
delete from lists where user=did;
delete from exclusions where user=did or excluded=did;
delete from raffles where user_1=did or user_2=did;
end$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `exclusions`
--

DROP TABLE IF EXISTS `exclusions`;
CREATE TABLE IF NOT EXISTS `exclusions` (
  `user` int(11) NOT NULL COMMENT 'Main user',
  `excluded` int(11) DEFAULT NULL COMMENT 'User excluded for main user',
  `year` year(4) NOT NULL COMMENT 'Year to exclusion'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='List of exclusions';

--
-- Dumping data for table `exclusions`
--

-- --------------------------------------------------------

--
-- Table structure for table `lists`
--

DROP TABLE IF EXISTS `lists`;
CREATE TABLE IF NOT EXISTS `lists` (
  `user` int(11) NOT NULL COMMENT 'User Id',
  `list` blob COMMENT 'User list',
  `image` longblob COMMENT 'Image data',
  `year` year(4) NOT NULL COMMENT 'Year of list creation'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='User''s lists data';

--
-- Dumping data for table `lists`
--

-- --------------------------------------------------------

--
-- Table structure for table `raffles`
--

DROP TABLE IF EXISTS `raffles`;
CREATE TABLE IF NOT EXISTS `raffles` (
  `universe` int(11) NOT NULL,
  `user_1` int(11) NOT NULL,
  `user_2` int(11) NOT NULL,
  `year` year(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `universes`
--

DROP TABLE IF EXISTS `universes`;
CREATE TABLE IF NOT EXISTS `universes` (
  `id` int(11) NOT NULL COMMENT 'Universe Id',
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Universe Name',
  `description` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Universe Description',
  `hash` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '(this year not used)',
  `stars` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Number of universe members',
  `supernovas` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Number of ready universe members',
  `year` year(4) NOT NULL COMMENT 'Year of creation universe'
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Related information for Universes';

--
-- Dumping data for table `universes`
--

INSERT INTO `universes` (`id`, `name`, `description`, `hash`, `stars`, `supernovas`, `year`) VALUES(1, 'Cosmos', 'Administrator Universe', NULL, 1, 5, 2015);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL COMMENT 'primary key',
  `name` varchar(80) COLLATE utf8_unicode_ci NOT NULL COMMENT 'name for user (max 60)',
  `email` varchar(80) COLLATE utf8_unicode_ci NOT NULL COMMENT 'email for user (max 60)',
  `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT 'password for user sha256',
  `admin` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Is universe administrator',
  `first_time` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'if is his first time',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'email confirmed or not',
  `ready` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'is ready or not',
  `universe` tinyint(3) unsigned NOT NULL COMMENT 'universe id',
  `year` year(4) NOT NULL COMMENT 'Year of register'
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Define all encrypted user personal information';

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `admin`, `first_time`, `status`, `ready`, `universe`, `year`) VALUES(1, 'em9sa2Vu', 'bWFyay5iZW5hdmVudEBnbWFpbC5jb20=', '$5$rounds=5000$universe1$iSts/e9BN1IbbTdzsSJpuTmH8MzkcvBF3FCGmgYO3p1', 1, 0, 1, 0, 1, 2015);

--
-- Triggers `users`
--
DROP TRIGGER IF EXISTS `user_registred`;
DELIMITER $$
CREATE TRIGGER `user_registred` AFTER INSERT ON `users`
 FOR EACH ROW begin
# Update universe stats
UPDATE zolken_invisiblefriend.universes 
SET stars = (
    SELECT COUNT(id)
    FROM zolken_invisiblefriend.users
    WHERE universe = NEW.universe
)
WHERE id = NEW.universe;

# Create empty list

insert into lists(user,year) values (NEW.id,NEW.year);

# Create empty exclusion

insert into exclusions(user,year) values (NEW.id,NEW.year);

end
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `user_removed`;
DELIMITER $$
CREATE TRIGGER `user_removed` AFTER DELETE ON `users`
 FOR EACH ROW BEGIN
    UPDATE zolken_invisiblefriend.universes SET stars = ( SELECT COUNT(id) FROM zolken_invisiblefriend.users WHERE universe = OLD.universe ) WHERE id = OLD.universe;

    DELETE FROM zolken_invisiblefriend.exclusions WHERE OLD.id = user or OLD.id = excluded;

    DELETE FROM zolken_invisiblefriend.lists WHERE OLD.id = user;

	DELETE FROM zolken_invisiblefriend.raffles WHERE OLD.id = user_1 or OLD.id = user_2;
	IF (SELECT COUNT(id) FROM zolken_invisiblefriend.users WHERE universe = OLD.universe) = 0 THEN DELETE FROM zolken_invisiblefriend.universes where id = OLD.universe;
	END IF;
END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `user_updated`;
DELIMITER $$
CREATE TRIGGER `user_updated` AFTER UPDATE ON `users`
 FOR EACH ROW IF (OLD.ready != NEW.ready) THEN
        UPDATE zolken_invisiblefriend.universes
        SET supernovas = (
            SELECT COUNT(id) FROM zolken_invisiblefriend.users
            WHERE universe = NEW.universe and ready = 1
        )
		WHERE id=NEW.universe;
END IF
$$
DELIMITER ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `exclusions`
--
ALTER TABLE `exclusions`
  ADD PRIMARY KEY (`user`) COMMENT 'main user', ADD KEY `date_index` (`year`) COMMENT 'Index for sort years';

--
-- Indexes for table `lists`
--
ALTER TABLE `lists`
  ADD KEY `user_year_index` (`user`,`year`) COMMENT 'Index for sort users by years';

--
-- Indexes for table `raffles`
--
ALTER TABLE `raffles`
  ADD KEY `universe_index` (`universe`) COMMENT 'For sort universe', ADD KEY `user1_index` (`user_1`), ADD KEY `user2_index` (`user_2`);

--
-- Indexes for table `universes`
--
ALTER TABLE `universes`
  ADD PRIMARY KEY (`id`) COMMENT 'primary key', ADD UNIQUE KEY `name` (`name`), ADD KEY `id` (`id`), ADD KEY `date_index` (`year`) COMMENT 'Index for sort years';

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`) COMMENT 'primary key', ADD KEY `universe_index` (`universe`) COMMENT 'Index for sort universes', ADD KEY `date_index` (`year`) COMMENT 'Index for sort years';

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `universes`
--
ALTER TABLE `universes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Universe Id',AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'primary key',AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
